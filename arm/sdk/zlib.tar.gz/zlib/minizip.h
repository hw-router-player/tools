
#ifndef _MINI_ZIP_H_INCLUDE
#define _MINI_ZIP_H_INCLUDE

#include "zlib.h"
#include "unzip.h"

extern int do_extract(unzFile uf, int opt_extract_without_path, int opt_overwrite, const char* password);
extern int do_list(unzFile uf);

#endif /* minizip.h */
